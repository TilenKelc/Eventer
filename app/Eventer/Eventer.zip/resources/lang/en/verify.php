<?php
return [



    'Verify Your Email Address' => 'Potrdite vaš e-poštni naslov.'



];
