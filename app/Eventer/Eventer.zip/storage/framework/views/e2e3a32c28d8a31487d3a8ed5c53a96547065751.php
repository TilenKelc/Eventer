<img src="https://izposoja.11-11.si/company_images/logo.png" width="150" height="58" alt="">
<br><br>

<h3>Pozdravljeni <?php echo e($customer->name . ' ' . $customer->surname); ?>,</h3>
<div>Obveščamo vas, da je vaša oprema pripravljena na prevzem in začetek uporabe.</div>
Lep pozdrav,
ekipa Sport11
<br><br>
<i>To je sistemsko generirano sporočilo, zato nanj ne odgovarjajte.</i>
<?php /**PATH /home/sport11rez/public_html/resources/views/mail/notification.blade.php ENDPATH**/ ?>
