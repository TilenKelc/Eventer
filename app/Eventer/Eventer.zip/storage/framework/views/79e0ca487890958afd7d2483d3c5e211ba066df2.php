
<?php $__env->startSection('content'); ?>

    <div class="cart">
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if($rent == null): ?>
            <div>
               Košarica je prazna.
            </div>
        <?php else: ?>

            <div class="container">
                <h4>Podatki o podjetju:</h4>
                <p><b>Naziv:</b> <?php echo e($company->name); ?><br>
                <b>Ulica: </b> <?php echo e($company->address); ?> <br>
                <b>Kraj: </b><?php echo e($company->postal_number); ?><br>
            </div>

            <div class="container">
                <h4>Podatki o stranki:</h4>
                <p><b>Ime:</b> <?php echo e($customer->name); ?><br>
                <b>Priimek: </b> <?php echo e($customer->surname); ?><br>
                <?php if($customer->company != null): ?>
                    <b>Podjetje:</b> <?php echo e($customer->company); ?><br>
                <?php endif; ?>
                <b>Email:</b> <?php echo e($customer->email); ?><br>
                <b>Tel:</b> <?php echo e($customer->phone_number); ?><br>
                <b>Ulica: </b> <?php echo e(App\Address::find($customer->address_id)->street); ?> <br>
                <b>Kraj: </b><?php echo e(App\Address::find($customer->address_id)->postal_code . ' ' . App\Address::find($customer->address_id)->city); ?><br>
            </div>

            </div>
            <div class="container vsebina_kosarice">
                <table class="table">
                    <thead>
                        <tr>
                            <!--<th scope="col">#</th>-->
                            <th scope="col">Oprema</th>
                            <th scope="col">Termin</th>
                            <th scope="col">Cena/dan</th>
                            <th scope="col">Cena skupaj</th>
                            <?php
                              if(count($products) > 1){
                            ?>
                            <th scope="col" style="text-align:center;">Odstrani</th>
                            <?php
                              }
                            ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $row_num = 1;
                        $total_price = 0;
                        $discount = 0;
                        foreach($products as $product){
                            $product_price = $product->price_per_day * $num_of_days;

                            if($num_of_days >= 8){
                                $product_price = $product_price - ($product_price * 0.35);
                                $discount = 35;

                            }else if($num_of_days >= 3 && $num_of_days <= 7){
                                $product_price = $product_price - ($product_price * 0.3);
                                $discount = 30;

                            }else if($num_of_days == 2){
                                $product_price = $product_price - ($product_price * 0.2);
                                $discount = 20;

                            }
                            $total_price += $product_price;

                            //if only one product, naredimo kr remove rent

                            echo '<tr>';
                               // echo '<th scope="row">' . $row_num . '</th>';
                                echo '<td>' . $product->name . ' (' . App\Size::find($product->size_id)->size . ')</td>';
                                echo '<td>' . date_format(date_create($rent->rental_from), "d.m.Y") . ' - ' . date_format(date_create($rent->rental_to), "d.m.Y") . '</td>';
                                echo '<td>' . $product->price_per_day . ' EUR</td>';
                                echo '<td>' . $product_price . ' EUR</td>';
                                if(count($products) > 1){
                                echo '<td style="text-align: center;"><a href="/removefromcart/'.$product->id.'"><span class="fa fa-times-circle" ></span></a></td>';
                              }
                            echo '</tr>';
                            $row_num += 1;
                        }
                        ?>
                    </tbody>
                </table>
                </div>
                <div class="container">
                <div class="checkout_bottom">
                    <label>Skupna cena izposoje: <b><?php echo e($total_price); ?></b> EUR*</label><br>
                    <label>Vaš vljučen popust: <b><?php echo e($discount); ?></b> %</label>
                    <div>
                        Opomba:
                        <p>
                            Na spletu plačate samo akontacijo, ki znaša <?php echo e(ceil($company->advance_payment_amount)); ?> EUR in vam bo v primeru pravočasnega vračila v celoti povrnjena.<br>
                            Znesek <?php echo e($total_price); ?> EUR plačate v poslovalnici Sport11 ob prevzemu.
                        </p>
                    </div>
                </div>
                <div class="finish_button_wrap">
                    <?php if(Auth::user()->isAgent()): ?>
                        <button class="btn custom-submit-btn"  id="confirmBtn">Potrdi rezervacijo</button>
                    <?php else: ?>
                        <button class="btn custom-submit-btn" id="confirmBtn">Nadaljuj na plačilo in potrdi rezervacijo</button>
                        <center><p>Plačilo rezervacije v višini <?php echo e(ceil($company->advance_payment_amount)); ?>€. Plačilo je možno s karticami Visa, Maestro, Mastercard,...</p></center>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        $(document).ready(function () {
            $('#confirmBtn').on('click', function(){
                if('<?php echo e(Auth::user()->isAgent()); ?>' == true){
                    Swal.fire({
                        title: 'Ali ste prepričani, da želite oddati naročilo?',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#26aa01',
                        cancelButtonColor: '#6a0505',
                        confirmButtonText: 'Da',
                        cancelButtonText: 'Ne, prekliči',
                    }).then((result) => {
                        if(result.isConfirmed) {
                            location.href = '<?php echo e(url("/payment/$rent_id")); ?>';
                        }
                    });
                }else{
                    location.href = '<?php echo e(url("/payment/$rent_id")); ?>';
                }
            });
        });
    </script>

    
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izposoja1111/public_html/resources/views/cart/show.blade.php ENDPATH**/ ?>