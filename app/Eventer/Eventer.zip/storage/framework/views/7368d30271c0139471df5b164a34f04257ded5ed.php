

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Urejanje uporabnika')); ?></div>

                <div class="card-body">
                    <form method="POST" action='<?php echo e(url("/user/save/$user->id")); ?>'>
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required autocomplete="name" autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="surname" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Surname')); ?></label>

                            <div class="col-md-6">
                                <input id="surname" type="text" class="form-control" name="surname" value="<?php echo e($user->surname); ?>" required autocomplete="surname" autofocus>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" disabled>
                            </div>
                        </div>

                        <hr class="style18">

                        <div class="form-group row">
                            <label for="street" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Street name')); ?></label>

                            <div class="col-md-6">
                                <input id="street" type="text" class="form-control" value="<?php if($user->address_id != null) { echo $user->getAddress()->street; } ?>"  name="street" required autocomplete="street">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__('City name')); ?></label>

                            <div class="col-md-6">
                                <input id="city" type="text" class="form-control" value="<?php if($user->address_id != null) { echo $user->getAddress()->city; } ?>"  name="city" required autocomplete="city">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="postal-code" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Postal code')); ?></label>

                            <div class="col-md-6">
                                <input id="postal-code" type="text" class="form-control" value="<?php if($user->address_id != null) { echo $user->getAddress()->postal_code; } ?>" name="postal_code" required autocomplete="postal_code">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="country-code" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Country code')); ?></label>

                            <div class="col-md-6">
                                <input id="country-code" type="text" class="form-control" value="<?php if($user->address_id != null) { echo $user->getAddress()->country_code; } ?>" name="country_code" required autocomplete="country_code">
                            </div>
                        </div>
                        <hr class="style18">

                        <div class="form-group row">
                            <label for="company" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Podjetje')); ?></label>

                            <div class="col-md-6">
                                <input id="company" type="text" class="form-control" value="<?php echo e($user->company); ?>" name="company">
                            </div>
                        </div>

                        <hr class="style18">
                        <div class="form-group row">
                            <label for="emso" class="col-md-4 col-form-label text-md-right"><?php echo e(__('EMŠO')); ?></label>

                            <div class="col-md-6">
                                <input id="emso" type="text" class="form-control" value="<?php echo e($user->emso); ?>" name="emso" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="type-of-id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Vrsta osebnega dokumenta')); ?></label>

                            <div class="col-md-6">
                                <select name="personal_id_type" id="type-of-id" class="form-control" required>
                                    <?php if($user->personal_id_type == 'personal_id'): ?>
                                        <option value="personal_id" selected>Osebna izkaznica</option>
                                    <?php else: ?>
                                        <option value="personal_id">Osebna izkaznica</option>
                                    <?php endif; ?>

                                    <?php if($user->personal_id_type == 'drivers_licence'): ?>
                                        <option value="drivers_licence" selected>Vozniško dovoljenje</option>
                                    <?php else: ?>
                                        <option value="drivers_licence">Vozniško dovoljenje</option>
                                    <?php endif; ?>

                                    <?php if($user->personal_id_type == 'passport'): ?>
                                        <option value="passport" selected>Potni list</option>
                                    <?php else: ?>
                                        <option value="passport">Potni list</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="personal_id_num" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Številka osebnega dokumenta')); ?></label>

                            <div class="col-md-6">
                                <input id="personal_id_num" type="text" class="form-control" value="<?php echo e($user->personal_id_number); ?>" name="personal_id_number" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="phone-num" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telefonska številka')); ?></label>

                            <div class="col-md-6">
                                <input id="phone-num" type="text" class="form-control" value="<?php echo e($user->phone_number); ?>" name="phone_num" required>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <?php if(Auth::user()->isAdmin()): ?>
                                    <button type="submit" class="btn custom-submit-btn">
                                        <?php echo e(__('Posodobi')); ?>

                                    </button>
                                <?php else: ?>
                                    <button type="button" class="btn custom-submit-btn demo">
                                        <?php echo e(__('Posodobi')); ?>

                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php if(Auth::check() && Auth::user()->isStaff()): ?>
        <div class="container">
            <table id="rentals-table">
                <thead>
                    <tr>
                        <th>Številka izposoje</th>
                        <th>Oprema</th>
                        <th>Datum od</th>
                        <th>Datum do</th>
                        <th>Skupna cena</th>
                        <th>Status</th>
                        <th>Pogodba o prevzemu</th>
                        <th>Pogodba o vračilu</th>
                        <th>Datum ustvarjanja</th>
                        <th>Pregled izposoje</th>
                    </tr>
                </thead>
            </table>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<script>
    if('<?php echo e(Auth::user()->isStaff()); ?>' == '1'){
        $('#rentals-table').DataTable({
            language: {
                "url": "//cdn.datatables.net/plug-ins/1.12.1/i18n/sl.json"
            },
            processing: false,
            serverSide: false,
            orderClasses: false,
            ajax: '<?php echo e(url("/user/get_rent/$user->id")); ?>',
            columns: [
                { data: 'id' },
                { data: 'equipment_ids' },
                { data: 'rental_from' },
                { data: 'rental_to' },
                { data: 'total_price' },
                { data: 'status' },
                { data: 'contract_filepath' },
                { data: 'return_confirmation_filepath' },
                { data: 'created_at' },
                { data: 'edit', orderable: false }
            ]
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezervacijademo/public_html/resources/views/user/edit.blade.php ENDPATH**/ ?>