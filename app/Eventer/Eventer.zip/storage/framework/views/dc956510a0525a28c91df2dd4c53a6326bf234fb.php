<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php
      if(!count($products)){
        echo "<span>V izbranem terminu ni na voljo noben kos opreme iz naše ponudbe.</span>";
      }
    ?>

    <?php if(count($products)): ?>

    <center><h3>Vse mize na voljo v izbranem terminu:</h3></center>
    <?php endif; ?>
    <div class="container category_view">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <a class="product_card" href='<?php echo e(url("/product/$product->id")); ?>'>
                  <div class="card_content">
                      <img class="prod-img" src='<?php echo e(url("$product->image")); ?>' alt="Slika" width="250" height="250">
                      <div class="card-body">
                          <h4 class="card-title"><?php echo e($product->name); ?></h4>
                          <span class="opis"><?php echo nl2br($product->details) ?></span>
                      </div>
                  </div>
                </a>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <script>
        $(".clickable").click(function() {
            window.location = $(this).find("a").attr("href");
            return false;
        });
    </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventer\resources\views/common/products_by_date.blade.php ENDPATH**/ ?>