
 
<?php $__env->startSection('content'); ?>
    <div class="container company_add">
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="header">
            <div class="content">Urejanje podatkov podjetja</div>
        </div>
        <form action='<?php echo e(url("/company/save")); ?>' method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>


            <div class="form-group col-md-4">
                <label class="col-form-label text-md">Ime podjetja:</label>
                <input type="text" class="form-control" name="name" value="<?php echo e($company->name); ?>" required>
            </div>

            <div class="form-group col-md-4">
                <label class="col-form-label text-md">Naslov podjetja:</label>
                <input type="text" class="form-control" name="address" value="<?php echo e($company->address); ?>" required>
            </div>

            <div class="form-group col-md-4">
                <label class="col-form-label text-md">Poštna številka:</label>
                <input type="text" class="form-control" name="postal_number" value="<?php echo e($company->postal_number); ?>" required>
            </div>

            <div class="form-group col-md-4">
                <label class="col-form-label text-md">Avans:</label>
                <input type="number" class="form-control" name="advance_payment_amount" value="<?php echo e($company->advance_payment_amount); ?>" required>
            </div>

            <div class="form-group col-md-4">
                <label class="col-form-label text-md">Nov logo podjetja:</label>
                <input type="file" class="form-control-file" name="image">
            </div>

            <div class="form-group col-md-4">
                <label>Trenutni logo:</label>
                <img src="<?php echo e(url("$company->image_path")); ?>" class="form-control" height="100px" width="100px" alt="logo">         
            </div>

            <div class="form-group col-md-4 submit-btn">
                <button type="submit" class="btn">Posodobi</button>
            </div>
        </form>    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izposoja1111/public_html/resources/views/company/edit.blade.php ENDPATH**/ ?>