
<?php $__env->startSection('content'); ?>
 
    <div class="container contract-article_add">
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if($contractArticle): ?>
            <div class="header">
                <div class="content">Dodajanje členov pogodbe</div>
            </div>
            <form action="<?php echo e(url("contract_article/save/$contractArticle->id")); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label class="col-form-label text-md">Naslov: </label>
                    <input type="text" class="form-control col-md-4" name="title" value="<?php echo e($contractArticle->title); ?>" />
                </div>

                <div class="form-group">
                    <label class="col-form-label text-md-right">Vsebina: </label>
                    <textarea id="text" name="content" class="form-control" cols="100" rows="20"><?php echo e($contractArticle->content); ?></textarea>

                    <input type="button" class="btn" value="[ime_in_priimek_stranke]" />
                    <input type="button" class="btn" value="[artikli]" />
                    <input type="button" class="btn" value="[skupna_cena_najema]" />
                    <input type="button" class="btn" value="[skupna_maloprodajna_cena]" />
                    <input type="button" class="btn" value="[najem_od]" />
                    <input type="button" class="btn" value="[najem_do]" />
                    <input type="button" class="btn" value="[st_kartice]" />
                </div>

                <div class="form-group footer">
                    <label class="col-form-label text-md">Ali bo besedilo imelo footer, za vpisovanje posebnosti?</label>
                    <label class="col-form-label text-md">Da/Ne:</label>
                    <?php if($contractArticle->footnote): ?>
                        <input type="checkbox" class="form-control btn" selected name="footnote"/>
                    <?php else: ?>
                        <input type="checkbox" class="form-control btn" name="footnote"/>
                    <?php endif; ?>
                </div>


                <div class="form-group submit-btn">
                    <button type="submit" class="btn">Posodobi</button>
                </div>
            </form>    
        <?php else: ?>
            <div class="header">
                <div class="content">Urejanje členov pogodbe</div>
            </div>
            <form action="<?php echo e(url('contract_article/save')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label class="col-form-label text-md">Naslov: </label>
                    <input class="form-control col-md-4" type="text" name="title" />
                </div>

                <div class="form-group">
                    <label class="col-form-label text-md-right">Vsebina: </label>
                    <textarea id="text" name="content" class="form-control" cols="100" rows="20"></textarea>

                    <input type="button" class="btn" value="[ime_in_priimek_stranke]" />
                    <input type="button" class="btn" value="[artikli]" />
                        <input type="button" class="btn" value="[skupna_cena_najema]" />
                        <input type="button" class="btn" value="[skupna_maloprodajna_cena]" />
                        <input type="button" class="btn" value="[najem_od]" />
                        <input type="button" class="btn" value="[najem_do]" />
                        <input type="button" class="btn" value="[st_kartice]" />
                </div>

                <div class="form-group footer">
                    <label class="col-form-label text-md">Ali bo besedilo imelo footer, za vpisovanje posebnosti?</label>
                    <label class="col-form-label text-md">Da/Ne:</label>
                    <input type="checkbox" class="form-control btn" name="footnote"/>
                </div>

                <div class="form-group submit-btn">
                    <button type="submit" class="btn">Dodaj</button>
                </div>
            </form>    
        <?php endif; ?>
        
    </div>

    <script>
        $(document).ready(function () {
            let currentInput = $('#text');
            $(document).on('focus', 'textarea', function() {
                currentInput = $(this);
            })

            $('input[type=button]').on('click', function(){
                let cursorPos = currentInput.prop('selectionStart');
                let v = currentInput.val();
                let textBefore = v.substring(0, cursorPos);
                let textAfter  = v.substring(cursorPos, v.length);
                currentInput.val(textBefore+ $(this).val() +textAfter);
            });
        });
    </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izposoja1111/public_html/resources/views/contract_article/add.blade.php ENDPATH**/ ?>