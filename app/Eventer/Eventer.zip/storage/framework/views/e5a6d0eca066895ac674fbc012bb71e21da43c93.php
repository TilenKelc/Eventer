
 
<?php $__env->startSection('content'); ?>
    <div class="container size_edit">
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="header">
            <div class="content">Urejanje zaporedja velikosti</div>
        </div>

        <div class="box-container" id="size-container">
            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div draggable="true" class="box"><?php echo e($size->size); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <form action="<?php echo e(url('size/save/new_order')); ?>" method="POST" enctype="multipart/form-data" id="formSize">
            <?php echo e(csrf_field()); ?>

    
            <input type="text" name="sizes" id="array_sizes" hidden>

            <div class="form-group submit-btn">
                <button type="button" class="btn" id="submitBtn">Posodobi</button>
            </div>
        </form>   
    </div>
    
    <script>
        $('#submitBtn').on('click', function(){
            let children = $('#size-container').children();

            console.log(children);
            let array = [];
            children.each(i => {
                array.push(children[i].textContent);
            });
            $('#array_sizes').val(array);
            $('#formSize').submit();
        });
        document.addEventListener('DOMContentLoaded', (event) => {
            var dragSrcEl = null;

            function handleDragStart(e) {
                this.style.opacity = '0.4';
                
                dragSrcEl = this;

                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/html', this.innerHTML);
            }

            function handleDragOver(e) {
                if (e.preventDefault) {
                    e.preventDefault();
                }

                e.dataTransfer.dropEffect = 'move';
                return false;
            }

            function handleDragEnter(e) {
                this.classList.add('over');
            }

            function handleDragLeave(e) {
                this.classList.remove('over');
            }

            function handleDrop(e) {
                if (e.stopPropagation) {
                    e.stopPropagation(); // stops the browser from redirecting.
                }
                
                if (dragSrcEl != this) {
                    dragSrcEl.innerHTML = this.innerHTML;
                    this.innerHTML = e.dataTransfer.getData('text/html');
                }
                return false;
            }

            function handleDragEnd(e) {
                this.style.opacity = '1';
                
                items.forEach(function (item) {
                    item.classList.remove('over');
                });
            }

            let items = document.querySelectorAll('.container .box');
                items.forEach(function(item) {
                item.addEventListener('dragstart', handleDragStart, false);
                item.addEventListener('dragenter', handleDragEnter, false);
                item.addEventListener('dragover', handleDragOver, false);
                item.addEventListener('dragleave', handleDragLeave, false);
                item.addEventListener('drop', handleDrop, false);
                item.addEventListener('dragend', handleDragEnd, false);
            });
        });



        /*
        $('#size-table').DataTable({
            language: {
               "url": "//cdn.datatables.net/plug-ins/1.12.1/i18n/sl.json"
            },
            processing: false,
            serverSide: false,
            orderClasses: false,
            order: [[1, 'desc']],
            ajax: '/size/get/all',
            columns: [
                { data: 'size', name: 'size' },
                { data: 'priority_order', name: 'priority_order' },
                { data: 'edit', orderable: false },
            ]
        });
        */
    </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sport11rez/public_html/resources/views/size/show_all.blade.php ENDPATH**/ ?>