

<?php $__env->startSection('content'); ?>
    <div>
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <iframe src='<?php echo e(url("contract/pdf/$rent->id")); ?>' title="description" width="100%" height="700px"></iframe>
        </div>
        <?php if((session()->get("signitureRenter") == null) && (session()->get("signitureRentee") == null)): ?>
            <div class="container podpisi_in_opombe" >
                <br><br><br>
                <div class="podpisi_wrap">
                  <div >
                      <label>Podpis najemodajalca:</label><br>
                      <canvas id="canvas-renter" class="canvas-container"></canvas><br>
                      <button type="button" id="clearCanvasRenter">Počisti</button>
                  </div>
                  <div >
                      <label>Podpis najemnika:</label><br>
                      <canvas id="canvas-rentee" class="canvas-container"></canvas><br>
                      <button type="button" id="clearCanvasRentee">Počisti</button>
                  </div>



                  </div>

                  <br><br>
                  <hr>
                  <div class="">
                    <label>Oprema, ki je predmet te najemne pogodbe ima izrazite predhodne sledi uporabe:</label><br>
                    <textarea id="wearTextarea"></textarea><br>
                    <button type="button" id="clearTextarea">Počisti</button><br><br>
                  </div>


                </div>


                <form action='<?php echo e(url("/contract/sign/$rent->id")); ?>' method="POST" id="signitureForm" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="signiture_renter" id="signitureRenter" value="" />
                    <input type="hidden" name="signiture_rentee" id="signitureRentee" value="" />
                    <textarea name="wear_marks" id="wearMarks" hidden></textarea>
                </form>
            </div>
            <div class="container">
                <button type="button" id="submitCanvas" class="btn custom-submit-btn">Shrani podpise in opombe</button>
            </div>
        <?php else: ?>
          <center>  <button type="button" id="confirmSave" class="btn custom-submit-btn">Potrdi</button></center>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/signature_pad@4.0.0/dist/signature_pad.umd.min.js"></script>

    <style>
        .canvas-container{
            border: 1px grey solid;
        }
    </style>
    <script>
        $(document).ready(function () {
            const canvasRenter = document.getElementById("canvas-renter");
            const canvasRentee = document.getElementById("canvas-rentee");

            if(canvasRenter && canvasRentee){
                const signaturePadRenter = new SignaturePad(canvasRenter);
                const signaturePadRentee = new SignaturePad(canvasRentee);

                $('#clearCanvasRenter').on('click', function(){
                    signaturePadRenter.clear();
                });

                $('#clearCanvasRentee').on('click', function(){
                    signaturePadRentee.clear();
                });

                $('#clearTextarea').on('click', function() {
                    $('#wearTextarea').val("");
                });

                $('#submitCanvas').on('click', function(){
                    let inputRenter = document.getElementById('signitureRenter');
                    let inputRentee = document.getElementById('signitureRentee');

                    inputRenter.value = signaturePadRenter.toDataURL();
                    inputRentee.value = signaturePadRentee.toDataURL();
                    $("#wearMarks").val($("#wearTextarea").val());
                    $('#signitureForm').submit();
                });
            }else{
                $('#confirmSave').on('click', function(){
                    $.ajax({
                        url: '<?php echo e(url("/contract/save/$rent->id")); ?>',
                        data: {},
                        type: "GET",
                        success: function (response) {
                            if(response){
                                window.location.replace('<?php echo e(url("/rent/edit/$rent->id")); ?>');
                            }
                        }
                    });
                });
            }
        });
    </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izposoja1111/public_html/resources/views/contract/show.blade.php ENDPATH**/ ?>