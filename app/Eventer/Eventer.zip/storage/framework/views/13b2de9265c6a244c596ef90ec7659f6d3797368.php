<!DOCTYPE html>
    <html><head>
        <meta charset="utf-8"/>

        <title>Pogodba št. <?php echo e($rent->id); ?></title>
        <style>
            *{ font-family: DejaVu Sans, sans-serif };
            body{
                position: relative;
            }
            .logo{
                position: absolute;
                top: 0px;
                right: 10px;
            }
            .data{
                text-align: center;
                padding: 20px;
            }
            .renter, .company{
                width: 50%;
                float: left;
            }
            .line{
                width: 60%;
                text-align: left;
            }
        </style>
    </head>
    <body>
        <?php
            $image_path = public_path() . $company->image_path;
            echo "<img class='logo' src='$image_path' alt='Logotip' width='100px' height='50px'>";
        ?>

        <h3 style="text-align: center;">Pogodba o izposoji športne opreme</h3>
        ki jo skleneta:<br>
        <?= $company->name ?>,
        <?= $company->address ?>
        <?= $company->postal_num ?> (v nadaljevanju najemodajalec)<br><br>

        in<br>
        <?= $customer->name . ' ' . $customer->surname ?><br>
        <?php if($customer->company != null): ?>
            Podjetje: <?php echo e($customer->company); ?><br>
        <?php endif; ?>
        Ulica: <?php echo e(App\Address::find($customer->address_id)->street); ?> <br>
        Kraj: <?php echo e(App\Address::find($customer->address_id)->city); ?><br>
        Pošta: <?php echo e(App\Address::find($customer->address_id)->postal_code); ?><br>
        Tel: <?= $customer->phone_number ?><br>
        EMŠO: <?= $customer->emso ?><br>
        Vrsta os. dok.:
        <?php
            switch($customer->personal_id_type){
                case 'personal_id':
                    echo "Osebna izkaznica";
                    break;
                case 'drivers_licence':
                    echo "Vozniško dovoljenje";
                    break;
                case 'passport':
                    echo "Potni list";
                    break;
            }
        ?><br>
        Št.os. dok.:
        <?= $customer->personal_id_number ?><br>
        (v nadaljevanju najemnik)<br>

        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h4 style="text-align: center;"><?php echo e($article['title']); ?></h4>
            <p><? echo strip_tags($article['content'], '<ul><li>') ?></p>
            <?php if($article['footnote']): ?>
                <?php if($wearMarks == null): ?>
                    Posebnosti: /
                <?php else: ?>
                    Posebnosti: <?php echo e($wearMarks); ?>

                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        <div>
            Dne <?php echo date("d. m. Y."); ?>
        </div>
        <div class="data">
            <div class="company">
                Najemodajalec:
                <br>
                <br>
                <img src="<?php echo e($signitureRenter); ?>" alt="Podpis" id="signiture">
                <hr class="line">
            </div>
            <div class="renter">
                Najemnik:
                <br>
                <br>
                <img src="<?php echo e($signitureRentee); ?>" alt="Podpis" id="signiture">
                <hr class="line">
            </div>
        </div>
    </body>
</html>
<?php /**PATH /home/izposoja1111/public_html/resources/views/contract/pdf.blade.php ENDPATH**/ ?>