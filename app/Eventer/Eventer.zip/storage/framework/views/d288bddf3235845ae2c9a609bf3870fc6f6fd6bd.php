

<?php $__env->startSection('content'); ?>

    <div class="container reservations_calendar">
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <center><h2>Izberite želen termin</h2></center>
        <div>Minimalno število dni za ta izdelek: <?php echo e($product->min_num_days); ?></div>
        <div>Maksimalno število dni za ta izdelek: <?php echo e($product->max_num_days); ?></div>
        <p>S klikom na dan v mesecu izberite začetek vaše izposoje. Termin lahko po potrebi raztegnete/podaljšate in naknadno premikate po koledarju.</p>
        <ul>
          <li>Na dneve označene z <span class="zasedeni"></span> izbrana oprema ni več na voljo.</li>
          <li>Dnevi označeni z <span class="vas_termin"></span> ozačujejo vaš termin.</li>
          <li>Z <span class="danes"></span> je za lažjo orientacijo označen današnji dan.</li>
        </ul>

        <div id="calendar"></div>

        <div class="confirm_dates">
           <center>
            <button style="button" id="submitDateBtn">
                <span class="fa fa-calendar-check-o"></span>
                Potrdi izbiro termina
                <span class="fa fa-calendar-check-o"></span>
            </button>
          </center>
        </div>
    </div>

    <style>
        td.fc-day.fc-day-past, .restricted {
            background-color: #EEEEEE;
        }
        .hideClass{
            display: none;
        }
        .fc-focus-event{
            height: 85px;
			display: flex;
			justify-content: center;
			align-items: center;

            font-size: 16px;
			font-weight: 600;
			text-transform: uppercase;

            background-color: #a20606;
        }
        .fc-daygrid-event-dot{
            display: none;
        }
    </style>

    <script src='https://cdn.jsdelivr.net/npm/moment@2.27.0/min/moment.min.js'></script>
    <!-- <script src="<?php echo e(asset('js/fullcalendar.min.js')); ?>" defer></script> -->
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/moment@5.5.0/main.global.min.js'></script>

    <script>
        $(document).ready(function () {
            let clicked = false;
            let search_from = null;
            let search_to = null;

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var is_weekend =  function(date){
                var dt = new Date(date);
                if(dt.getDay() == 6 || dt.getDay() == 0){
                    return true;
                } 
                return false;
            }

            let events = [];
            $.ajax({
                url: '<?php echo e(route("reservation.full")); ?>',
                data: {
                    product_id: "<?= $product->id ?>"
                },
                type: "GET",
                success: function (response) {
                    response.forEach(element => {
                        let start = moment(element["date_from"]).subtract(1, 'day').format('Y-MM-DD');
                        let end = moment(element["date_to"]).add(1, 'day').format('Y-MM-DD');

                        events.push({
                            'start': start,
                            'end': end + " 23:59:00",
                            className: 'hideClass'
                        });
                    });
                }
            }).done(function(){
                getCalendar();
            });

            function getCalendar(){
                var calendar = document.getElementById('calendar');
                var calendar = new FullCalendar.Calendar(calendar, {
                    locale: 'sl',
                    displayEventTime: false,
                    selectable: true,
                    firstDay: 1, // monday
                    //selectHelper: true,

                    editable: true,

                    selectOverlap: false,
                    eventOverlap: false,
                    nextDayThreshold: '23:59:00',
                    events: events,
                    // selectConstraint: {
                    //     start: moment().subtract(1, 'days'),
                    //     end: '2100-12-25'
                    // },
                    eventConstraint: {
                        start: moment().subtract(30, 'days'),
                        end: moment().subtract(1, 'days'),
                    },
                    selectAllow: function(select) {
                        return moment().diff(select.start, 'days') <= 0;
                    },
                    customButtons: {
                        prev: {
                            text: 'Prev',
                            click: function() {
                                calendar.prev();

                                var current = new Date();
                                var view = calendar.view;

                                let start = new Date(view.activeStart);
                                let end = new Date(view.activeEnd);                                

                                if(current > start && current < end){
                                    $(".fc-prev-button").prop('disabled', true);
                                    $(".fc-prev-button").addClass('fc-state-disabled');
                                }
                                else {
                                    $(".fc-prev-button").removeClass('fc-state-disabled');
                                    $(".fc-prev-button").prop('disabled', false);
                                }
                            }
                        },
                        next: {
                            text: 'Next',
                            click: function() {
                                calendar.next();

                                var current = new Date();
                                var view = calendar.view;

                                let start = new Date(view.currentStart);
                                let end = new Date(view.currentEnd);

                                if(current > start && current < end){
                                    $(".fc-prev-button").prop('disabled', true);
                                    $(".fc-prev-button").addClass('fc-state-disabled');
                                }
                                else {
                                    $(".fc-prev-button").removeClass('fc-state-disabled');
                                    $(".fc-prev-button").prop('disabled', false);
                                }
                            }
                        },
                        today: {
                            text: 'Today',
                            click: function(){
                                calendar.today();

                                var current = new Date();
                                var view = calendar.view;

                                let start = new Date(view.currentStart);
                                let end = new Date(view.currentEnd);

                                if(current > start && current < end){
                                    $(".fc-prev-button").prop('disabled', true);
                                    $(".fc-prev-button").addClass('fc-state-disabled');
                                }
                                else {
                                    $(".fc-prev-button").removeClass('fc-state-disabled');
                                    $(".fc-prev-button").prop('disabled', false);
                                }
                            }
                        }
                    },
                    viewDidMount: function(arg) {
                        view = arg.view;
                        //var minDate = moment();
                        const current = new Date();
                        const start = new Date(view.activeStart);
                        const end = new Date(view.activeEnd);

                        //if(minDate._d >= view.activeStart && minDate._d <= view.activeEnd){
                        if(current >= start && current <= end){
                            $(".fc-prev-button").prop('disabled', true);
                            $(".fc-prev-button").addClass('fc-state-disabled');
                        }
                        else {
                            $(".fc-prev-button").removeClass('fc-state-disabled');
                            $(".fc-prev-button").prop('disabled', false);
                        }
                    },
                    dayCellDidMount: function (arg){
                        let date = arg.date;
                        let cell = arg.el;

                        if(events.length != 0){
                            events.forEach(element => {
                                var date_start = new Date(element['start']);
                                date_start.setDate(date_start.getDate() - 1);
                                let end = new Date(element['end']); 

                                if(date >= date_start && date <= end) {
                                  cell.classList.add('restricted');
                                }
                            });
                        }
                    },
                    select: function(arg){
                        let startDate = arg.startStr;
                        let endDate = arg.endStr;                    

                        let fixedEndDate = moment(arg.end).subtract(1, 'day').format('Y-MM-DD');

                        if(clicked){
                            calendar.getEventById('set').remove();
                        }
                    
                        calendar.addEvent({
                            start: startDate,
                            end: endDate,
                            id: 'set',
                            title: 'Vaš termin',
                            className: 'fc-focus-event'
                        });

                        search_from = startDate;
                        search_to = fixedEndDate;

                        clicked = true;
                        calendar.unselect();
                    },
                    eventResize: function(arg) {
                      // ko uporabnik razteza event, moramo posodabljat "date_to"
                      // v skladu s dokumentacijo, enako kot pri select funkciji, tudi pri resizu odštejemo 1 dan
                      search_to = moment(arg.event.end).subtract(1, 'day').format('Y-MM-DD');
                    },
                    // eventDrop: function(arg) {
                    //   // console.log("drop se je zgodil");
                    //   search_from = moment(arg.event.start).format('Y-MM-DD');
                    //   search_to = moment(arg.event.end).subtract(1, 'day').format('Y-MM-DD');
                    // },

                    eventDrop: function(arg) {   
                        if(moment(arg.event.start) < moment()) {
                          //console.log("trenutni datum je večji od začetka eventa");
                          arg.revert();
                        } else {
                          //console.log("trenutni datum je manjši od začetka eventa");
                          search_from = moment(arg.event.start).format('Y-MM-DD');
                          search_to = moment(arg.event.end).subtract(1, 'day').format('Y-MM-DD');
                        }
                        
                    },
                });
                calendar.render();
            };

            $('#submitDateBtn').on('click', function(){
                if(search_from == null || search_to == null){
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Datuma ni izbranega!',
                    });
                }else{
                    const date1 = new Date(search_from);
                    const date2 = new Date(search_to);
                    let diffTime = Math.abs(date2 - date1);
                    let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                    diffDays += 1;

                    if(search_from == search_to && is_weekend(search_from)){
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Za vikend ni mogoče izbrati samo enega dne!',
                        });
                    }else if(diffDays > '<?php echo e($product->max_num_days); ?>' || diffDays < '<?php echo e($product->min_num_days); ?>'){
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Minimalno število dni za ta izdelek je <?php echo e($product->min_num_days); ?>, maxsimalno pa <?php echo e($product->max_num_days); ?>!',
                        });
                    }else{
                        Swal.fire({
                            title: 'Ali ste prepričani?',
                            text: "Trenutno izbrani datum je od " + moment(search_from).format('DD.MM.Y') + " do " + moment(search_to).format('DD.MM.Y'),
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#26aa01',
                            cancelButtonColor: '#6a0505',
                            confirmButtonText: 'Da, ta termin mi ustreza.',
                            cancelButtonText: 'Ne, prekliči',
                        }).then((result) => {
                            if(result.isConfirmed) {
                                $.ajax({
                                    url: "<?php echo e(url('reservation/add')); ?>",
                                    data: {
                                    product_id: "<?= $product->id ?>",
                                    start: search_from,
                                    end: search_to
                                    },
                                    type: "POST",
                                    success: function (response) {
                                        window.location.replace('<?php echo e(url("/product/$product->id")); ?>');
                                    }
                                });
                            }
                        })
                    }
                }
            });
        });
    </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sport11rez/public_html/resources/views/reservation/show.blade.php ENDPATH**/ ?>