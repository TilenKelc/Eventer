

<?php $__env->startSection('content'); ?>
    <div>
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--
        <?php if($rent == null): ?>
            <form action="<?php echo e(url('rent/save')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <?php if($user->isAgent()): ?>
                    <label>Customer:</label>
                    <input type="text" id="customer" placeholder="Ime in priimek" />
                    <input type="text" name="customer_id" id="customer_id" hidden/>
                    <div id="customersList"></div><br>
                <?php endif; ?>

                <label>Oprema:</label>
                <select name="equipment">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>

                <label>Najem od:</label>
                <input type="date" name="rental_from"><br>

                <label>Najem do:</label>
                <input type="date" name="rental_to"><br>

                <button type="submit">Add</button>
            </form>
        <?php else: ?>-->

        <form action='<?php echo e(url("rent/save/$rent->id")); ?>' method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>


            <div>
                <?php
                $status = "";
                switch($rent->status){
                    case 'pending':
                        $status = "V stanju čakanja";
                        break;
                    case 'successfully_paid':
                        $status = "Uspešno plačano";
                        break;
                    case 'in_progress':
                        $status = "V teku";
                        break;
                    case 'completed':
                        $status = "Zaključeno";
                        break;
                    case 'canceled':
                        $status = "Preklicano";
                        break;
                }
                ?>
                <h3>Status izposoje: <?php echo e($status); ?></h3>
            </div>

            <div><h5>Podatki o stranki:</h5>
              <p><b>Ime:</b> <?php echo e($customer->name); ?><br>
              <b>Priimek: </b> <?php echo e($customer->surname); ?><br>
              <b>Email:</b> <?php echo e($customer->email); ?><br>
              <b>Tel:</b> <?php echo e($customer->phone_number); ?><br>
              <b>Ulica: </b> <?php echo e(App\Address::find($customer->address_id)->street); ?> <br>
              <b>Kraj: </b><?php echo e(App\Address::find($customer->address_id)->city); ?><br>
              <b>Pošta: </b><?php echo e(App\Address::find($customer->address_id)->postal_code); ?>

            </div>

            <h5>Seznam opreme:</h5>
            <ul>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($product->name . ' (' . $product->product_id .')'); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <div>Izposoja od: <b><?php echo e(date('Y-m-d',strtotime($rent->rental_from))); ?></b></div>
            <div>Izposoja do: <b><?php echo e(date('Y-m-d',strtotime($rent->rental_to))); ?></b></div>
            <br><br>

            <h3>Upravljanje izposoje:</h3>


            <?php if($rent->status == 'successfully_paid'): ?>
                <?php
                $date = date('Y-m-d H:i:s', strtotime($rent->rental_from . ' + 12 hour'));
                //$date2 = date('Y-m-d H:i:s', strtotime($rent->rental_from . ' + 12 hour'));

                $d1= new DateTime(null, new DateTimeZone('Europe/Ljubljana'));
                $d2= new DateTime($date);
                $diff = $d1->diff($d2);
                $hours = $diff->h + ($diff->days * 24);

                $cancel = true;
                if($d1 > $d2){
                    $cancel = false;
                }
                ?>
                <br>
                <div class="preklic_najema">
                  Prekliči rezervacijo.
                  (preklic rezervacije manj kot 72 ur pred začetkom izposoje ni mogoč).
                </div>
                <?php
                if((($hours - 2) > 72) && $cancel){
                    echo '<div><button type="submit" class="btn custom-submit-btn" name="action" value="cancel">Prekliči</button></div>';
                }else{

                    echo '<div><button class="btn custom-submit-btn" style="cursor:not-allowed;" disabled>Prekliči</button></div>';
                }
                ?>
                <?php if(Auth::user()->isStaff()): ?>
                    <div>
                    <br><br>
                        <label>Pripravljeno na prevzem?</label>
                        <div>
                            <?php if($rent->ready_for_take_over): ?>
                                <span class="btn custom-submit-btn">Da</span>
                            <?php else: ?>
                                <button type="submit" class="btn custom-submit-btn" name="action" value="ready">Da</button>
                            <?php endif; ?>
                        </div>
                        <br><br>
                    </div>
                    <div>
                      <h5>Ob prevzemu upreme:</h5>
                        <button type="submit" name="action" class="btn custom-submit-btn" value="rent_contract">Izdaj pogodbo</button>
                    </div>
                <?php else: ?>
                    <div>
                    <br><br>
                        <label>Pripravljeno na prevzem?</label>
                        <div>
                            <?php if($rent->ready_for_take_over): ?>
                                <span class="btn custom-submit-btn">Da</span>
                            <?php else: ?>
                                <span class="btn custom-submit-btn">Ne</span>
                            <?php endif; ?>
                        </div>
                        <br><br>
                    </div>
                <?php endif; ?>
            <?php elseif($rent->status == 'in_progress' && Auth::user()->isStaff()): ?>
                <div>
                   <h5>Ko stranka vrne opremo:</h5>
                    <button type="submit" class="btn custom-submit-btn" name="action" value="return_contract">Izdaj potrdilo o vračilu opreme</button>
                </div>
            <?php elseif($rent->status == 'completed' && Auth::user()->isStaff()): ?>
                <?php if($rent->return_confirmation_issued && !$customer->isAgent()): ?>
                    <div>
                      <p>V primeru, da je bila oprema ustrezno vrnjena, znesek akontacije vrnete stranki s klikom na spodnji gumb.</p>
                        <button type="submit" class="btn custom-submit-btn" name="action" value="refund">Refund</button>
                    </div>
                <?php else: ?>
                    <div>
                        <?php if(!$customer->isAgent()): ?>
                            <p>Sredstva so že bila vrnjena stranki.</p>
                        <?php else: ?>
                          <p>Nobena akcija ni na voljo.</p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(!Auth::user()->isStaff()): ?>
                <div>
                    <h5>Pogodba o izposoji</h5>
                    <?php if($rent->contract_filepath != null): ?>
                        <a href='<?php echo e($rent->contract_filepath); ?>' target='_blank'><i class='fa fa-file-pdf-o' aria-hidden='true'></i></a>
                    <?php else: ?>
                        Dokument še ni na voljo
                    <?php endif; ?>
                </div>
                <div>
                    <h5>Potdilo o vračilu</h5>
                    <?php if($rent->return_confirmation_filepath != null): ?>
                        <a href='<?php echo e($rent->return_confirmation_filepath); ?>' target='_blank'><i class='fa fa-file-pdf-o' aria-hidden='true'></i></a>
                    <?php else: ?>
                        Dokument še ni na voljo
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </form>
        <!--<?php endif; ?>-->
    </div>
    <!--
    <script>
        /*
        $(document).ready(function () {
            $.noConflict();

            $('#customer').keyup(function(){
                var query = $(this).val();
                if(query != ''){
                    var _token = $('input[name="_token"]').val();
                    $.ajax({
                        url:" route('autocomplete.fetch') ",
                        method:"POST",
                        data:{query:query, _token:_token},
                        success:function(data){
                            $('#customersList').fadeIn();
                            $('#customersList').html(data);
                        }
                    });
                }else{
                    $('#customersList').fadeOut();
                }
            });

            $(document).on('click', '.najdenrezultat', function(){
                let customer = $(this).text();
                customer = customer.replace(/\s\s+/g, ' ');
                let customer_data = customer.split('|||')[0];
                let customer_id = customer.split('|||')[1];

                $('#customer').val(customer_data);
                $('#customer_id').val(customer_id);
                $('#customerList').fadeOut();
            });
        });
        */
    </script>
    -->
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sport11rez/public_html/resources/views/rent/add.blade.php ENDPATH**/ ?>