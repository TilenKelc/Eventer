<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <h3>Restavracije</h3>

        <?php $__currentLoopData = $categories->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row no-gutters categories_wrap">
            <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e(url("/category/$category->id")); ?>" class="card_single">
                <img class="card-img-top" src='<?php echo e(url("$category->category_image")); ?>' alt="Slika" width="250" height="250">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($category->name); ?></h5>
                    <span class="btn custom-submit-btn">Več</span>
                </div>
              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventer\resources\views/category/show.blade.php ENDPATH**/ ?>