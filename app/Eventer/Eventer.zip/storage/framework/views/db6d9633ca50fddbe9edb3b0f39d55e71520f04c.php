<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Registracija')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ime')); ?>*</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="surname" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Priimek')); ?>*</label>

                            <div class="col-md-6">
                                <input id="surname" type="text" class="form-control <?php if ($errors->has('surname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('surname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="surname" value="<?php echo e(old('surname')); ?>" required autocomplete="surname" autofocus>

                                <?php if ($errors->has('surname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('surname'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-mail naslov')); ?>*</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="phone_number" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telefonska številka')); ?>*</label>

                            <div class="col-md-6">
                                <input id="phone_number" type="text" class="form-control" value="<?php echo e(old('phone_number')); ?>"  name="phone_number" required autocomplete="tel">
                            </div>
                        </div>
                        <hr>
                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Geslo')); ?>*</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ponovi geslo')); ?>*</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>
                        <hr>

                        <div class="form-group row">
                            <label for="street" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Naslov')); ?>*</label>

                            <div class="col-md-6">
                                <input id="street" type="text" class="form-control" value="<?php echo e(old('street')); ?>"  name="street" required autocomplete="street">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Kraj')); ?>*</label>

                            <div class="col-md-6">
                                <input id="city" type="text" class="form-control" value="<?php echo e(old('city')); ?>"  name="city" required autocomplete="city">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="postal-code" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pošta')); ?>*</label>

                            <div class="col-md-6">
                                <input id="postal-code" type="text" class="form-control" value="<?php echo e(old('postal_code')); ?>"  name="postal_code" required autocomplete="postal_code">
                            </div>
                        </div>

                        <!--<div class="form-group row">
                            <label for="country-code" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Country code')); ?></label>

                            <div class="col-md-6">
                                <input id="country-code" type="text" class="form-control" value="<?php echo e(old('country_code')); ?>"  name="country_code" required autocomplete="country_code">
                            </div>
                        </div>-->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn custom-submit-btn">
                                    <?php echo e(__('Ustvari uporabniški račun')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    hr.style10 {
        border-top: 1px dotted #8c8b8b;
        border-bottom: 1px dotted #fff;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventer\resources\views/auth/register.blade.php ENDPATH**/ ?>