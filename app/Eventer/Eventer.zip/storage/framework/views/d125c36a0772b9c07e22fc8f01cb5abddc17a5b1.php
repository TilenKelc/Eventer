

<?php $__env->startSection('content'); ?>

    <div class="product_view">
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container breadcrumbs">
            <a href='<?php echo e(url("/category/$category->id")); ?>'><?php echo e($category->name); ?></a> > <?php echo e($product->name); ?>

        </div>
        <div class="container">
            <div class="row product_upper">
                <div class="col-sm">
                    <img src='<?php echo e(url("$product->image")); ?>'>
                </div>
                <div class="col-sm right_content_wrap">
                  <div class="upper_part">
                    <h2 class="product_name"><?php echo e($product->name); ?></h2>
                    <h5 class="velikost">Velikost: <?php echo e(App\Size::find($product->size_id)->size); ?></h5>

                    <?php if($already_in_cart): ?>
                        <?php
                            $rent = App\Rent::find(session()->get('rent_id'));
                            $rental_to = new DateTime($rent->rental_to);
                            $rental_from = new DateTime($rent->rental_from);
                            $interval = $rental_from->diff($rental_to);
                            $num_of_days = $interval->format('%a');
                            $num_of_days += 1;

                            $discount = 0;

                            $product_price = $product->price_per_day * $num_of_days;

                            if($num_of_days >= 8){
                                $product_price = $product_price - ($product_price * 0.35);
                                $discount = 35;

                            }else if($num_of_days >= 3 && $num_of_days <= 7){
                                $product_price = $product_price - ($product_price * 0.3);
                                $discount = 30;

                            }else if($num_of_days == 2){
                                $product_price = $product_price - ($product_price * 0.2);
                                $discount = 20;
                            }
                        ?>
                        <span class="cena">Vaša cena izposoje: <span class="price_per_day"><?php echo e($product_price); ?>€</span><a href="/cenik#cenik" class="fa fa-question-circle"  data-toggle="tooltip" data-placement="top" title="Cenik izposoje"  target="_blank"></a></span><br>
                        <span class="cena">Vaš vključen popust: <span class="price_per_day"><?php echo e($discount); ?>%</span></span>
                    <?php else: ?>
                        <span class="cena">Cena izposoje/dan: <span class="price_per_day"><?php echo e($product->price_per_day); ?>€</span><a href="/cenik#cenik" class="fa fa-question-circle" data-toggle="tooltip" data-placement="top" title="Cenik izposoje" target="_blank"></a></span>
                    <?php endif; ?>

                    <?php if(session()->get("rental_to") != null && session()->get("rental_from")): ?>
                        <?php if($already_in_cart): ?>
                            <div class="addto">
                              <!-- <button type="button" class="btn already_in_cart"><span class="fa fa-calendar-check-o"></span>Artikel že v vaši košarici</button> -->
                                <a href="/cart" type="button" class="btn already_in_cart"><span class="fa fa-calendar-check-o"></span>Zaključi rezervacijo</a>
                            </div>

                            <!--<a class="cart_link" href="/cart">Kliknite tukaj za zaključek rezervacije.</a>-->
                        <?php else: ?>
                            <div class="addto">
                                <?php $url = url("/reservation/add/$product->id") ?>
                                <button type="button" class="btn put_in_cart" onclick="location.href='<?= $url ?>'"><span class="fa fa-calendar-plus-o"></span>Dodaj v košarico</button>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="addto">
                            <?php $url = url("/reservation/show/$product->id"); ?>
                            <button type="button" class="btn pick_date" onclick="location.href='<?= $url ?>'"><span class="fa fa-calendar"></span>Izberi termin</button>
                        </div>
                    <?php endif; ?>
                  </div>

                  <div class="bottom_part">
                    <div class="opis"><b>Opis:</b><br><?php echo nl2br($product->details); ?></div>
                    <div><a href="<?php echo e($product->about_url); ?>" class="more_about">Več o izdelku</a></div>
                  </div>






                </div>
            </div>
            <div class="row product_bottom">
            
            <?php if(count($recommended_products) > 0): ?>
              <h2>Priporočeno za vas:</h2>
                <div class="col carousel">
                    <?php $__currentLoopData = $recommended_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $product_link = url('/product/' . $product->id); ?>
                        <div class="product-link" onclick="location.href='<?php echo e($product_link); ?>'">
                            <div class="related_card">
                                <img class="" src='<?php echo e(url("$product->image")); ?>'>
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                    <p class="card-text">Velikost: <?php echo e(App\Size::find($product->size_id)->size); ?></h5></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            </div>
        </div>
    </div>

    <style>
        .product-link:hover{
            cursor: pointer;
        }
    </style>

    <script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
    <script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            $('.carousel').slick({
                // centerMode: true,
                // centerPadding: '60px',
                slidesToShow: 3,
                responsive: [
                    {
                    breakpoint: 768,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '40px',
                        slidesToShow: 3
                    }
                    },
                    {
                    breakpoint: 480,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '40px',
                        slidesToShow: 1
                    }
                    }
                ]
            });
        });

        $(function () {
          $('[data-toggle="tooltip"]').tooltip()
        })
    </script>

   

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izposoja1111/public_html/resources/views/product/show.blade.php ENDPATH**/ ?>