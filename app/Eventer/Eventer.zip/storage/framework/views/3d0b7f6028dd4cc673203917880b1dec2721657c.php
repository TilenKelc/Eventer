

<?php $__env->startSection('content'); ?>

    <div>
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table id="size-table">
            <thead>
                <tr>
                    <th>Velikost</th>
                    <th>Prioriteta</th>
                    <th>Uredi</th>
                </tr>
            </thead>
        </table>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    
    <script>
        $('#size-table').DataTable({
            language: {
               "url": "//cdn.datatables.net/plug-ins/1.12.1/i18n/sl.json"
            },
            processing: false,
            serverSide: false,
            orderClasses: false,
            order: [[1, 'desc']],
            ajax: '/size/get/all',
            columns: [
                { data: 'size', name: 'size' },
                { data: 'priority_order', name: 'priority_order' },
                { data: 'edit', orderable: false },
            ]
        });
    </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izposoja1111/public_html/resources/views/size/table.blade.php ENDPATH**/ ?>