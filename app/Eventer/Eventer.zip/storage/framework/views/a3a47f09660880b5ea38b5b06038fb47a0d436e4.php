

<?php $__env->startSection('content'); ?>

    <div>
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <table id="products-table">
            <thead>
                <tr>
                    <th>Šifra artikla</th>
                    <!-- <th>Slika</th> -->
                    <th>Naziv</th>
                    <!--<th>Maloprodajna cena</th>-->
                    <th>Cena na dan</th>
                    <th>Minimalno število dni</th>
                    <th>Maksimalno število dni</th>
                    <!--<th>Priporočeni izdelki</th>-->
                    <th>Datum ustvarjanja</th>
                    <th>Datum posodabljanja</th>
                    <th>Uredi</th>
                    <th>Izbriši</th>
                </tr>
            </thead>
        </table>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $('#products-table').DataTable({
            language: {
               "url": "//cdn.datatables.net/plug-ins/1.12.1/i18n/sl.json"
            },
            processing: false,
            serverSide: false,
            orderClasses: false,
            ajax: '/product/all',
            columns: [
                { data: 'product_id', name: 'product_id' },
                // { data: 'image', name: 'image', orderable: false},
                { data: 'name', name: 'name' },
                //{ data: 'retail_price', name: 'retail_price'},
                { data: 'price_per_day', name: 'price_per_day'},
                { data: 'min_num_days', name: 'min_num_days'},
                { data: 'max_num_days', name: 'max_num_days'},
                //{ data: 'recommended_items', name: 'recommended_items'},
                { data: 'created_at', name: 'created_at' },
                { data: 'updated_at', name: 'updated_at' },
                { data: 'edit', orderable: false },
                { data: 'delete', orderable: false }
            ]
        });
        function confirmAction() {
            return confirm("Ali ste prepričani, da želite izbrisati ta artikel?");
        }
    </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezervacijademo/public_html/resources/views/product/index.blade.php ENDPATH**/ ?>