<h3>Obvestilo</h3>
<div>Oseba <?php echo e($customer->name . ' ' . $customer->surname); ?>, je danes <?php echo e(date('d.m.Y h:i')); ?> potrdila rezervacijo
od <?php echo e(date('d.m.Y h:i', strtotime($rent->rental_from))); ?> do <?php echo e(date('d.m.Y h:i', strtotime($rent->rental_to))); ?>,
v restavraciji <?php echo e(App\Category::find($products[0]->category_id)->name); ?>.

<br><br>
<i>To je sistemsko generirano sporočilo, zato nanj ne odgovarjajte.</i>
<?php /**PATH C:\xampp\htdocs\Eventer\resources\views/mail/info.blade.php ENDPATH**/ ?>