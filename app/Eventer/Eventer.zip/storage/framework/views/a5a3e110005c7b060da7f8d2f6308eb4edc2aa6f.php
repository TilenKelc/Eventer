<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">

      <div id="cenik">
      <h3>Cenik izposoje</h3>
        <!--
      <ul>
      <h6>E-BIKE</h6>
      <li>1-dan         |	 <b>45.00 €</b></li>
      <li>2-dni         |	-20.00 %</li>
      <li>3-7 dni       |	-30.00 %</li>
      <li>8 dni ali več |	-35.00 %</li>
      </ul>

      <ul>
        <h6>OSTALA KOLESA</h6>

        <li>1-dan         |	<b>35.00 €</b></li>
        <li>2-dni         |	-20.00 %</li>
        <li>3-7 dni 	    |  -30.00 %</li>
        <li>8 dni ali več |	-35.00 %</li>
      </ul>


      <ul>
        <h6>REPAIR SET (torbica+zračnica+snemalci+pumpica)</h6>
        <li>1-dan         |	  5.00 €</li>
        <li>2-dni         |	-20.00 %</li>
        <li>3-7 dni       |	-30.00 %</li>
        <li>8 dni ali več |	-35.00 %</li>
      </ul>-->

      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
      </p>

      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
      </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezervacijademo/public_html/resources/views/common/cenik.blade.php ENDPATH**/ ?>