

<?php $__env->startSection('content'); ?>

    <div>
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action='<?php echo e(url("contract/add/$rent_id/save")); ?>' method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>


            <label>Podjetje (to polje ni obvezno):</label>
            <input type="text" name="company" value="<?php echo e($customer->company); ?>"/><br>

            <label>EMŠO:</label>
            <input type="text" name="emso" value="<?php echo e($customer->emso); ?>" required/><br>
            <input type="hidden" name="user_id" value="<?php echo e($customer->id); ?>"/>

            <label>Vrsta osebnega dokumenta:</label>
            <select name="personal_id_type" required>
                <?php if($customer->personal_id_type == 'personal_id'): ?>
                    <option value="personal_id" selected>Osebna izkaznica</option>
                <?php else: ?>
                    <option value="personal_id">Osebna izkaznica</option>
                <?php endif; ?>

                <?php if($customer->personal_id_type == 'drivers_licence'): ?>
                    <option value="drivers_licence" selected>Vozniško dovoljenje</option>
                <?php else: ?>
                    <option value="drivers_licence">Vozniško dovoljenje</option>
                <?php endif; ?>

                <?php if($customer->personal_id_type == 'passport'): ?>
                    <option value="passport" selected>Potni list</option>
                <?php else: ?>
                    <option value="passport">Potni list</option>
                <?php endif; ?>
            </select><br>

            <label>Številka osebnega dokumenta:</label>
            <input type="text" name="personal_id_number" value="<?php echo e($customer->personal_id_number); ?>"><br>

            <label>Telefonska številka:</label>
            <input type="text" name="phone_number" value="<?php echo e($customer->phone_number); ?>"><br>

            <button type="submit" class="btn custom-submit-btn">Shrani podakte</button>
        </form>
    </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izposoja1111/public_html/resources/views/contract/add.blade.php ENDPATH**/ ?>