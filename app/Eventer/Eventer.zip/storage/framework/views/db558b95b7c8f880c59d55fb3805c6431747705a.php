<!DOCTYPE html>
    <html><head>
        <meta charset="utf-8"/>

        <title>Potrdilo o vračilu št. <?php echo e($rent->id); ?></title>
        <style>
            *{ font-family: DejaVu Sans, sans-serif }; 
            body{
                position: relative;
            }
            .logo{
                position: absolute;
                top: 0px;
                right: 10px;
            }
            .data{
                text-align: center;
                padding: 20px;
            }
            .renter, .company{
                width: 50%;
                float: left;
            }
            .line{
                width: 60%;
                text-align: left;
            }
        </style>
    </head>
    <body>
        <?php
            $image_path = public_path() . $company->image_path;
            echo "<img class='logo' src='$image_path' alt='Logotip' width='100px' height='50px'>";
        ?>

        <h3 style="text-align: center;">Potrdilo o vračilu opreme</h3>
        
        Spodaj podpisani <?= $agent->name ?> <?= $agent->surname ?> potrjujem, da je bila od <?= $customer->name ?> <?= $customer->surname ?> 
        vrnjena sledeča oprema:

        <ul>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>Artikel: <?= $product->name ?>, serijska številka: <?= $product->product_id ?>,
                vrednost (maloprodajna cena) <?= $product->retail_price ?> EUR.
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <div>
            <?php if($wearMarks == null): ?>
                Posebnosti: /
            <?php else: ?>
                Posebnosti: <?php echo e($wearMarks); ?>

            <?php endif; ?>
        </div>
        <div>
            Dne <?php echo date("d. m. Y."); ?>
        </div>
        <div class="data">
            <div class="company">
                Najemodajalec: 
                <br>
                <br>
                <img src="<?php echo e($signitureRenter); ?>" alt="Podpis" id="signiture">
                <hr class="line">
            </div>
            <div class="renter">
                Najemnik: 
                <br>
                <br>
                <img src="<?php echo e($signitureRentee); ?>" alt="Podpis" id="signiture">
                <hr class="line">
            </div>
        </div>
    </body>
</html><?php /**PATH /home/izposoja1111/public_html/resources/views/contract/return_pdf.blade.php ENDPATH**/ ?>