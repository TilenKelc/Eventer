<br><br>
<img src="https://izposoja.11-11.si/company_images/logo.png" width="150" height="58" alt="">
<br><br>
<?php /**PATH /home/izposoja1111/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/header.blade.php ENDPATH**/ ?>