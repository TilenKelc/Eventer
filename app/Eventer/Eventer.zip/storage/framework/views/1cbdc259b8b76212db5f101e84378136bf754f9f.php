<!doctype html>
<html lang="en">
  <head>
  	<title>Rezervacija Demo</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!--<link  rel="icon" type="image/x-icon" href="<?php echo e(URL::asset('/image/favicon_round_1111-opt.png')); ?>" />
    <link  rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::asset('/image/favicon_round_1111-opt.png')); ?>"/>-->

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('css/tauria_bs.css')); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" >
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">

    <link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">

    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js"></script>

    <!--<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.css"/>-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/combine/npm/fullcalendar@5.11.0/main.min.css,npm/fullcalendar@5.11.0/main.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <style>
      #setDate{
        display: none;
      }
    </style>
  </head>
  <body>

		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<h1>
          <a href="/" class="logo">
            <!--<img src="<?php echo e(URL::asset('/image/sidebar_logo.png')); ?>" alt="sport_11_izposoja_opreme" class="logo_small">
            <img src="<?php echo e(URL::asset('/image/sidebar_logo_full.png')); ?>" alt="sport_11_izposoja_opreme" class="logo_big">-->
            Logo
          </a>
        </h1>
        <ul class="list-unstyled components mb-5">
          <!--<li>
            <a href="https://11-11.si"><span class="fa fa-sign-out fa-rotate-180"></span><?php echo e(__('Nazaj na 11-11.si')); ?></a>
          </li>-->
          <li>
            <a href="<?php echo e(url('/category/index')); ?>"><span class="fa fa-cubes"></span><?php echo e(__('Kategorije')); ?></a>
          </li>



          <?php if(Auth::check() && Auth::user()->isStaff()): ?>
            <li>
              <a href="<?php echo e(url('/product/admin/index')); ?>"><span class="fa fa-cube"></span><?php echo e(__('Oprema')); ?></a>
            </li>
            <li>
              <a href="<?php echo e(url('/contract_article/index')); ?>"><span class="fa fa-file-word-o"></span><?php echo e(__('Členi pogodbe')); ?></a>
            </li>
            <li>
              <a href="<?php echo e(url('/rent/show/all')); ?>"><span class="fa fa-archive"></span> <?php echo e(__('Rezervacije')); ?></a>
            </li>
            <!--<li>
              <a href="<?php echo e(url('/size/show/all')); ?>"><span class="fa fa-arrows-v"></span><?php echo e(__('Velikosti')); ?></a>
            </li>-->
            <li>
              <a href="<?php echo e(url('/user/show/all')); ?>"><span class="fa fa-users"></span><?php echo e(__('Stranke')); ?></a>
            </li>
          <?php endif; ?>

          <?php if(Auth::check() && Auth::user()->isAdmin()): ?>
            <li>
              <a href="<?php echo e(url('/agent/index')); ?>"><span class="fa fa-users"></span><?php echo e(__('Agenti')); ?></a>
            </li>
            <li>
              <a href="<?php echo e(url('/company/edit')); ?>"><span class="fa fa-building"></span> <?php echo e(__('Podatki o podjetju')); ?></a>
            </li>
          <?php endif; ?>

          <?php if(Auth::check()): ?>
            <li>
              <?php if(Auth::user()->isStaff()): ?>
                <a href="<?php echo e(url('/myrents')); ?>"><span class="fa fa-history"></span> <?php echo e(__('Interne rezervacije')); ?></a>
              <?php else: ?>
                <a href="<?php echo e(url('/myrents')); ?>"><span class="fa fa-history"></span> <?php echo e(__('Moji renti')); ?></a>
              <?php endif; ?>
            </li>
            <li>
              <a href="<?php echo e(url('/user/edit/' . Auth::id())); ?>"><span class="fa fa-cogs"></span> <?php echo e(__('Osebni podatki')); ?></a>
            </li>
          <?php endif; ?>

          <li>
            <a href="<?php echo e(url('/cenik')); ?>"><span class="fa fa-credit-card"></span><?php echo e(__('Cenik')); ?></a>
          </li>
          <li>
            <a href="<?php echo e(url('/pravila-in-pogoji-poslovanja')); ?>"><span class="fa fa-tasks"></span><?php echo e(__('Pravila in pogoji poslovanja')); ?></a>
          </li>
        </ul>

        <div class="footer">
        	<!-- <p>
					  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
					</p> -->
        </div>
    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5">

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">

            <button type="button" id="sidebarCollapse" class="btn custom-submit-btn">
              <i class="fa fa-bars"></i>
              <span class="sr-only">Toggle Menu</span>
            </button>

             <!--<img src="<?php echo e(URL::asset('/image/sport11-crnlogo.png')); ?>" alt="sport_11_izposoja_opreme" class="logo_mobile_center">-->

            <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-chevron-down"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="nav navbar-nav ml-auto">


                <?php
                $url = Request::url();
                $base_url = url('/');
                $current_url = substr($url, strlen($base_url));
                if(!empty($current_url)){
                  $current = explode("/", $current_url)[1];
                }else{
                  $current = "";
                }
                ?>

                <!-- <li class="nav-item">
                  <a class="nav-link" href="javascript:void(0)" id="dateSearchBtn"><?php echo e(__('Iskanje po datumu')); ?></a>
                </li> -->
                <?php if($current == 'category'): ?>
                  <?php if(Auth::check() && Auth::user()->isStaff()): ?>
                    <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('/category/admin/index')); ?>"><?php echo e(__('Prikaži vse kategorije')); ?></a>
                    </li>
                    <li class="nav-item">
                      <?php if(Auth::user()->isAdmin()): ?>
                        <a class="nav-link" href="<?php echo e(url('/category/add')); ?>"><?php echo e(__('Dodaj kategorijo')); ?></a>
                      <?php else: ?>
                        <a class="nav-link demo" href="javascript:void(0)"><?php echo e(__('Dodaj kategorijo')); ?></a>
                      <?php endif; ?>
                    </li>
                  <?php endif; ?>
                  <!--<?php if(session()->get('rent_id') == null ): ?>
                    <li class="nav-item">
                      <a class="nav-link" href="javascript:void(0)" id="dateSearchBtn"><?php echo e(__('Iskanje po datumu')); ?></a>
                    </li>
                  <?php endif; ?>-->
                <?php elseif($current == 'contract_article'): ?>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/contract_article/index')); ?>"><?php echo e(__('Prikaži vse člene pogodbe')); ?></a>
                  </li>
                  <li class="nav-item">
                      <?php if(Auth::user()->isAdmin()): ?>
                        <a class="nav-link" href="<?php echo e(url('/contract_article/add')); ?>"><?php echo e(__('Dodaj člen pogodbe')); ?></a>
                      <?php else: ?>
                        <a class="nav-link demo" href="javascript:void(0)"><?php echo e(__('Dodaj člen pogodbe')); ?></a>
                      <?php endif; ?>
                  </li>
                <?php elseif($current == 'size'): ?>
                  <!--<li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/size/show/all')); ?>"><?php echo e(__('Prikaži vse velikosti')); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/size/show/order')); ?>"><?php echo e(__('Uredi zaporedje velikosti')); ?></a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('/size/add')); ?>"><?php echo e(__('Dodaj velikost')); ?></a>
                  </li>-->
                <?php elseif($current == 'rent' && Auth::user()->isStaff()): ?>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/rent/show/all')); ?>"><?php echo e(__('Prikaži vse izposoje')); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/rent/show/pending')); ?>"><?php echo e(__('Status: PENDING')); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/rent/show/successfully_paid')); ?>"><?php echo e(__('Status: USPEŠNO PLAČANO')); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/rent/show/in_progress')); ?>"><?php echo e(__('Status: V TEKU')); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/rent/show/completed')); ?>"><?php echo e(__('Status: ZAKLJUČENO')); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/rent/show/canceled')); ?>"><?php echo e(__('Status: PREKLICANO')); ?></a>
                  </li>
                <?php elseif($current == 'agent'): ?>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/agent/index')); ?>"><?php echo e(__('Prikaži vse agente')); ?></a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('/agent/add')); ?>"><?php echo e(__('Dodaj agenta')); ?></a>
                  </li>
                <?php elseif($current == 'product'): ?>
                  <?php if(Auth::check() && Auth::user()->isStaff()): ?>
                    <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(url('/product/admin/index')); ?>"><?php echo e(__('Vsa razpoložljiva oprema')); ?></a>
                    </li>
                    <li class="nav-item">
                      <?php if(Auth::user()->isAdmin()): ?>
                        <a class="nav-link" href="<?php echo e(url('/product/add')); ?>"><?php echo e(__('Dodaj opremo')); ?></a>
                      <?php else: ?>
                        <a class="nav-link demo" href="javascript:void(0)"><?php echo e(__('Dodaj opremo')); ?></a>
                      <?php endif; ?>
                    </li>
                  <?php endif; ?>
                <?php endif; ?>
                <!--
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('product/add')); ?>"><?php echo e(__('add product')); ?></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('category/add')); ?>"><?php echo e(__('add category')); ?></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#"><?php echo e(__('Search by date')); ?></a>
                </li>
                -->
              </ul>

              <!--<div>
                <?php if(Auth::check()): ?>
                <a href="<?php echo e(url('cart')); ?>" >
                  <i class="fa fa-shopping-cart" aria-hidden="true"></i>(<?php echo e($cart_num); ?>)
                </a>
                <?php endif; ?>
              </div>-->

              <ul class="navbar-nav ml-auto">
                  <li class="nav-item active">
                      <a class="nav-link" href="<?php echo e(url('/')); ?>">Na začetek</a>
                  </li>

                  <?php if(session()->get('rent_id') == null ): ?>
                    <?php if(Request::path() != '/' && Request::path() != "home-bikes"): ?>
                    <li class="nav-item">
                      <a class="nav-link" href="javascript:void(0)" id="dateSearchBtn"><i class="fa fa-search"></i><?php echo e(__('Iskanje po datumu')); ?></a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>

                  <!-- Authentication Links -->
                  <?php if(auth()->guard()->guest()): ?>
                      <li class="nav-item">
                          <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Prijava')); ?></a>
                      </li>
                      <?php if(Route::has('register')): ?>
                          <li class="nav-item">
                              <!--<a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registracija')); ?></a>-->
                              <a class="nav-link demo" href="javascript:void(0)"><?php echo e(__('Registracija')); ?></a>
                          </li>
                      <?php endif; ?>
                  <?php else: ?>


                    <li class="nav-item">
                      <a href="<?php echo e(url('cart')); ?>" class="nav-link">
                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>(<?php echo e($cart_num); ?>)
                      </a>
                    </li>
                      <li class="nav-item dropdown">
                          <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                              <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                          </a>

                          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                 onclick="event.preventDefault();
                                 console.log('zere');
                                               document.getElementById('logout-form').submit();">
                                  <?php echo e(__('Odjava')); ?>

                              </a>

                              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                  <?php echo csrf_field(); ?>
                              </form>
                          </div>
                      </li>
                  <?php endif; ?>
              </ul>
            </div>
          </div>
        </nav>

        <div class="alert alert-info alert-dismissible fade show" id="setDate">
          <a href="#" class="close" id="closeSetDate">&times;</a>
          Določi svoj termin:
          <form action='<?php echo e(url("/reservation/set")); ?>' method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div>
              <label>Začetek izposoje: </label>
              <input type="text" name="set_from_date" id="set_from_date" readonly="readonly" />
              <!-- <input type="date" name="set_from_date" id="set_from_date"  /> -->
            </div>
            <div>
              <label>Opremo bom vrnil: </label>
              <input type="text" name="set_to_date" id="set_to_date" readonly="readonly"/>
              <!-- <input type="date" name="set_to_date" id="set_to_date" /> -->
            </div>
            <div>
              <button type="submit" class="btn btn-info">Potrdi izbrane datume</button>
            </div>
          </form>
        </div>

        <?php if(session()->get("rental_to") != null && session()->get("rental_from") != null): ?>
          <div class="alert alert-info alert-dismissible fade show" role="alert">
            <a href="#" class="close" id='reservation_reset'>&times;</a>
            Izbran termin:

            <div>Začetek izposoje: <?php echo e(date_format(date_create(session()->get("rental_from")), "d.m.Y")); ?></div>
            <div>Opremo bom vrnil: <?php echo e(date_format(date_create(session()->get("rental_to")), "d.m.Y")); ?></div>
            <?php if(!request()->is('products/bydate*')): ?>
            <br>
            <center><a href='<?php echo e(url("/products/bydate")); ?>' class="btn custom-submit-btn">Vsa razpoložljiva oprema v izbranem terminu</a></center>
            <?php endif; ?>
          </div>
        <?php endif; ?>
        <main class="py-4">

            <?php if($current == 'rent' && Auth::user()->isStaff()): ?>

            <div class="bljiznice text-center" style="margin-bottom: 24px;">
            <a class="" style="padding: 10px; background: lightcoral;  color: #fff; border: 1px solid #a20606; margin-right: 10px; border-radius: 4px;" href="<?php echo e(url('/rent/show/today_out')); ?>"><span class="fa fa-exclamation-circle"></span> <?php echo e(__('Današnji prevzemi')); ?></a>
            <a class="" style="padding: 10px; background: blanchedalmond; border: 1px solid #a20606; margin-right: 10px; border-radius: 4px;" href="<?php echo e(url('/rent/show/today_in')); ?>"><span class="fa fa-share-square"></span> <?php echo e(__('Današnja vračila')); ?></a>
            <a class="" style="padding: 10px; background: cornsilk; border: 1px solid #a20606; margin-right: 10px; border-radius: 4px;" href="<?php echo e(url('/rent/show/week_out')); ?>"><span class="fa fa-calendar"></span> <?php echo e(__('Prevzemi 7 dni')); ?></a>
            </div>
            <?php endif; ?>


            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <!-- <h2 class="mb-4">Sidebar #07</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p> -->
      </div>
		</div>

    <!-- <script src="<?php echo e(asset('js/jquery.min.js')); ?>" defer></script> -->
    <script src="<?php echo e(asset('js/popper.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/datepicker-sl.js')); ?>" defer></script>

    <script>
      $(document).ready(function () {
        $(document).on('click', ".demo", function () {
          Swal.fire(
            'Preklicano',
            'Ta funkcionalnost na demo verziji ne deluje',
            'info'
          )
        });

        $('#reservation_reset').on('click', function(){
          Swal.fire({
            title: 'Ali ste prepričani, da želite ponastaviti datum?',
            // text: "Tega dejanja ni mogoče razveljaviti",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Da, izbrati želim druge datume.',
            cancelButtonText: 'Ne, prekliči.',
          }).then((result) => {
            if(result.isConfirmed) {
              $.get("/reservation/delete", function(data) {
                Swal.fire(
                  'Datum ponastavljen!',
                  '',
                  'success'
                )
                location.reload();
              });
            }

          });
        });

        $('#dateSearchBtn').on('click', function(){
          $('#setDate').show();
          $("html, body").animate({ scrollTop: 0 }, "slow");
          return false;
        });

        /*
        $('#setDateBtnSubmit').on('click', function(){
          let data = {
            from: $('#set_from_date').val(),
            to:$('#set_to_date').val()
          };

          if(data['from'] >= data['to']){
            alert('Datum od dne, ne sme biti večji od datuma do dne');

          }else{
            $.post("<?php echo e(url('/reservation/set')); ?>", data)
            .done(function(response){
              alert("success");
              console.log(response);
            });
          }
        });
        */

        $('#closeSetDate').on('click', function(){
          $('#setDate').hide();
        });

        // ob kliku na prvi datepicker vplivamo na minDate drugega datepickerja

        $("#set_from_date").datepicker({
          minDate: new Date(),
          onSelect: function(dateText, inst){
            var datepicker_1_val = $("#set_from_date").datepicker('getDate');
            datepicker_1_val.setDate(datepicker_1_val.getDate()+1);
            $("#set_to_date").datepicker("option","minDate", datepicker_1_val);
          }
        });

        $("#set_to_date").datepicker();



      });
    </script>
  </body>
</html>
<?php /**PATH /home/rezervacijademo/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>