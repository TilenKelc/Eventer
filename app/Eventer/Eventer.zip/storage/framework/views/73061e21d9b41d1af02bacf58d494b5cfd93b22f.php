<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
      <img src="https://www.11-11.si/pub/media/wysiwyg/Izposoja-koles-banner.jpg"/>

      <p>Bi želeli pred nakupom kolo testirati ali pa si le želite na kolo vendar se vam nakup ne zdi smiseln, ker to potrebujete samo nekajkrat na leto? V Šport 11 smo za vas pripravili idealno rešitev: Rent a bike. Vsa kolesa so redno vzdrževana in pripravljena na nove aktivnosti. V naši rent floti lahko poiščete kolesa znamk Focus in Giant.</p>

      <div class="kartice_odlocitev">
        <a href="" class="kartica">
         <h3>Išči glede na datum</h3>
        </a>

        <a href="" class="kartica">
         <h3>Najprej izberi svoj tip kolesa</h3>
        </a>
      </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sport11rez/public_html/resources/views/home.blade.php ENDPATH**/ ?>