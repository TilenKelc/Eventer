

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php
      if(!count($products)){
        echo "<span>Za izbran termin ni na voljo koles iz te kategorije.</span>";
      }
    ?>

    <?php if(count($products)): ?>
    <div class="container text-center">
        <div class="dropdown velikosti">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Velikosti
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href='<?php echo e(url("/category/$category_id")); ?>'>Vse velikosti</a> 
                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="dropdown-item" href='<?php echo e(url("/category/$category_id/$size->size")); ?>'><?php echo e($size->size); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="container category_view">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <a class="product_card" href='<?php echo e(url("/product/$product->id")); ?>'>
                  <div class="card_content">
                      <img class="prod-img" src='<?php echo e(url("$product->image")); ?>' alt="Slika" width="250" height="250">
                      <div class="card-body">
                          <h4 class="card-title"><?php echo e($product->name); ?></h4>
                          <span class="velikost">Velikost: <?php echo e(App\Size::find($product->size_id)->size); ?></span>
                          <span class="cena">Cena izposoje/dan: <?php echo e($product->price_per_day); ?>€</span>
                          <span class="opis"><?php echo nl2br($product->details) ?></span>
                      </div>
                  </div>
                </a>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <script>
        $(".clickable").click(function() {
            window.location = $(this).find("a").attr("href");
            return false;
        });
    </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sport11rez/public_html/resources/views/category/products.blade.php ENDPATH**/ ?>