<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container thank_you">
        <div class="jumbotron text-center">
            <h1 class="display-3">Hvala!</h1>
            <p class="lead">Potrditev rezervacije je bila uspešna.<br>
            <hr>
            <p class="lead">
              <a class="btn btn-primary btn-sm" href="<?php echo e(url('/')); ?>" role="button">Nazaj na začetek</a>
            </p>
        </div>
    </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventer\resources\views/rent/thank_you.blade.php ENDPATH**/ ?>