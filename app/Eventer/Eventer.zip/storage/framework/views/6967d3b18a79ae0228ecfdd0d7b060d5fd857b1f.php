<?php if(count($errors) > 0): ?>
<div class="alert alert-danger" role="alert">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Whoops! Something went wrong!</strong>
    <br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php elseif(!empty($successMssg)): ?>
    <div class="alert alert-success" role="alert">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e($successMssg); ?>

    </div>
<?php elseif(!empty($errorMssg)): ?>
    <div class="alert alert-danger" role="alert">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e($errorMssg); ?>

    </div>
<?php elseif(session()->get("successMssg") != null): ?>
    <div class="alert alert-success" role="alert">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(session()->get("successMssg")); ?>

    </div>
    <?php session(['successMssg' => null]) ?>
<?php elseif(session()->get("errorMssg") != null): ?>
    <div class="alert alert-danger" role="alert">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(session()->get("errorMssg")); ?>

    </div>
    <?php session(['errorMssg' => null]) ?>
<?php endif; ?><?php /**PATH /home/sport11rez/public_html/resources/views/common/errors.blade.php ENDPATH**/ ?>