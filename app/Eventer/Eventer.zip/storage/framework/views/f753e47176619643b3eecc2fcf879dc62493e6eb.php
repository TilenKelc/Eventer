
 
<?php $__env->startSection('content'); ?>
 
    <div class="container agent_add">
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if($agent == null): ?>
            <div class="header">
                <div class="content">Dodajanje novih agentov</div>
            </div>
            <form action="<?php echo e(url('agent/save')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

    
                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Ime:</label>
                    <input type="text" class="form-control" name="name" required>
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Priimek:</label>
                    <input type="text" class="form-control" name="surname" required>
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Email:</label>
                    <input type="text" class="form-control" name="email" >
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Geslo:</label>
                    <input type="password" class="form-control" name="password" required>
                </div>

                <!--<label>Seznam strank:</label>
                <input type="text" name="customer_list"><br>-->
                <div class="form-group col-md-4 submit-btn">
                    <button type="submit" class="btn">Add</button>
                </div> 
            </form>            
        <?php else: ?>
            <div class="header">
                <div class="content">Urejanje podatkov agentov</div>
            </div>
            <form action='<?php echo e(url("agent/save/$agent->id")); ?>' method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Ime:</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($agent->name); ?>">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Priimek:</label>
                    <input type="text" class="form-control" name="surname" value="<?php echo e($agent->surname); ?>">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Email:</label>
                    <input type="text" class="form-control" name="email" value="<?php echo e($agent->email); ?>">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Geslo:</label>
                    <input type="password" class="form-control" name="password"><br>
                </div>

                <!--
                <label>Seznam strank:</label>
                <input type="text" name="customer_list" value="<?php echo e($agent->customer_list); ?>"><br>
                -->
                <div class="form-group col-md-4 submit-btn">
                    <button type="submit" class="btn">Add</button>
                </div>
            </form>           
            <form action='<?php echo e(url("agent/delete/$agent->id")); ?>' method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group submit-btn">
                    <button type="submit" class="btn">Izbriši</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izposoja1111/public_html/resources/views/agent/add.blade.php ENDPATH**/ ?>