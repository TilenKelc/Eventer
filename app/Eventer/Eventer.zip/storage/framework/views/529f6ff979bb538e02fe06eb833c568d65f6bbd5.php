<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-center">
                <div class="card-header"><b><?php echo e(__('Potrditi morate vaš e-poštni naslov!')); ?></b></div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('Nova povezava za potrditev registracije je bila poslana na vaš e-poštni naslov.')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('Pred uporabe rezervacijskega sistema v polnem obsegu, preverite elektronsko pošto in potrdite vaš e-poštni naslov.')); ?>

                    <br><br>
                    <?php echo e(__('Če našega sporočila niste prejeli ali pa ga ne najdete')); ?>, <a href="<?php echo e(route('verification.resend')); ?>"><?php echo e(__('kliknite tukaj')); ?></a> <?php echo e(__(' in poslali vam ga bomo ponovno. Povezava za potrditev je veljavna 1 uro.')); ?>.
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rezervacijademo/public_html/resources/views/auth/verify.blade.php ENDPATH**/ ?>