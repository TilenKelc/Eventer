

<?php $__env->startSection('content'); ?>

    <div class="container product_add">
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if($product == null): ?>
            <div class="header">
                <div class="content">Dodajanje novih artiklov</div>
            </div>
            <form action="<?php echo e(url('product/save')); ?>" method="POST" enctype="multipart/form-data" id="data-form">
                <?php echo e(csrf_field()); ?>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Naziv</label>
                    <input type="text" class="form-control" name="name">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Šifra:</label>
                    <input type="text" class="form-control" name="product_id">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Povezava na več o artiklu:</label>
                    <input type="text" class="form-control" name="about_url">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Opis:</label>
                    <textarea type="text" class="form-control" name="details"></textarea>
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Maloprodajna cena:</label>
                    <input type="number" class="form-control" step=".01" min="0" name="retail_price">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Slike:</label>
                    <input type="file" class="form-control-file" name="product_image" required>
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Kategorija:</label>
                    <select name="category_id">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Cena izposoje na dan:</label>
                    <input type="number" class="form-control" step=".01" name="price_per_day">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Minimalna časovna enota:</label>
                    <input type="number" class="form-control" step="1" min="1" name="min_num_days">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Maximalna časovna enota:</label>
                    <input type="number" class="form-control" step="1" min="1" name="max_num_days">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Velikost:</label>
                    <select name="size_id">
                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($size->id); ?>"><?php echo e($size->size); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small class="form-text text-muted"><a href="<?php echo e(url('size/add')); ?>">Velikost ni na seznamu?</a></small>
                </div>

                <div class="form-group row col-md-4">
                    <label class="col-form-label text-md">Priporočeni:</label><br>
                    <input type="text" class="product-item form-control custom-search-form" id="active-item">

                    <i class="fa fa-plus-circle hide custom-search-btn" aria-hidden="true" id="add-item"></i>
                    <div id="productList"></div>
                    <input type="text" name="recommended_items" id="recommended_items" hidden>
                </div>

                <div class="form-group submit-btn">
                    <button type="button" id="submitBtn" class="btn">Dodaj</button>
                </div>
            </form>
        <?php else: ?>
            <div class="header">
                <div class="content">Posodobitev artikla</div>
            </div>
            <form action='<?php echo e(url("product/save/$product->id")); ?>' method="POST" enctype="multipart/form-data" id="data-form">
                <?php echo e(csrf_field()); ?>


                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Naziv</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($product->name); ?>">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Šifra:</label>
                    <input type="text" class="form-control" name="product_id" value="<?php echo e($product->id); ?>">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Povezava na več o artiklu:</label>
                    <input type="text" class="form-control" name="about_url" value="<?php echo e($product->about_url); ?>">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Opis:</label>
                    <textarea type="text" class="form-control" name="details" rows="5"><?php echo e($product->details); ?></textarea>
                </div>
                
                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Maloprodajna cena:</label>
                    <input type="number" class="form-control" step=".01" min="0" name="retail_price" value="<?php echo e($product->retail_price); ?>">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Slika:</label>
                    <input type="file" class="form-control-file" name="product_image">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Trenutna slika:</label>
                    <img src="<?php echo e(url($product->image)); ?>" class="form-control" alt="Slika produkta">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Kategorija:</label>
                    <select name="category_id">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->category_id == $category->id): ?>
                                <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>  

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Cena izposoje na dan:</label>
                    <input type="number" step=".01" class="form-control" name="price_per_day" value="<?php echo e($product->price_per_day); ?>">
                </div>
            
                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Minimalna časovna enota:</label>
                    <input type="number" step="1" min="1" class="form-control" name="min_num_days" value="<?php echo e($product->min_num_days); ?>">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Maximalna časovna enota:</label>
                    <input type="number" step="1" min="1" class="form-control" name="max_num_days" value="<?php echo e($product->max_num_days); ?>">
                </div>

                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Velikost:</label>
                    <select name="size_id">
                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->size_id == $size->id): ?>
                                <option value="<?php echo e($size->id); ?>" selected><?php echo e($size->size); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($size->id); ?>"><?php echo e($size->size); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select><br>
                    <small class="form-text text-muted"><a href="<?php echo e(url('size/add')); ?>">Velikost ni na seznamu?</a></small>
                </div>

                <div class="form-group row col-md-4">
                    <label class="col-form-label text-md">Priporočeni:</label><br>
                    <?php $__currentLoopData = $recommended; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommended_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="text" class="product-item form-control custom-search-form" value='<?php echo e($recommended_product->name . ' (' . $recommended_product->product_id . ')'); ?>' disabled><i class='fa fa-minus-circle remove-item custom-search-btn' aria-hidden='true'></i><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <input type="text" class="product-item form-control custom-search-form" id="active-item">
                    <i class="fa fa-plus-circle hide custom-search-btn" aria-hidden="true" id="add-item"></i>
                    
                    <div id="productList"></div>
                    <input type="text" name="recommended_items" id="recommended_items" hidden>
                </div>

                <div class="form-group submit-btn">
                    <button type="button" id="submitBtn" class="btn">Shrani</button>
                </div>
            </form>
            <form action='<?php echo e(url("product/delete/$product->id")); ?>' method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group submit-btn">
                    <button type="submit" class="btn">Izbriši</button>
                </div>
            </form>
        <?php endif; ?>
    </div>


    <style>
        .hide{
            display: none;
        }
    </style>

    <script>
        $(document).ready(function () {
            function getIds(){
                let allProducts = $('.product-item').map((_,el) => el.value).get();
                let product_ids = [];

                for(let product of allProducts){
                    if(product == ''){
                        continue;
                    }
                    try{
                        let product_id = product.split('(')[1].toString();
                        product_id = product_id.replace(')', '');
                        product_id = product_id.replaceAll('\'', '');
                        product_id.trim();
                        product_ids.push(parseInt(product_id));
                    }catch (error) {
                        // invalid
                    }
                }
                return product_ids;
            }

            $(document).on('keyup', '.product-item', function(){
                var query = $(this).val();
                if(query != ''){
                    var _token = $('input[name="_token"]').val();
                    $.ajax({
                        url:"<?php echo e(route('product.fetch')); ?>",
                        method:"POST",
                        data:{
                            query: query, 
                            already: getIds(), 
                            _token:_token},
                        success:function(response){
                            $('#productList').fadeIn();
                            $('#productList').html(response);
                        }
                    });
                }else{
                    $('#productList').fadeOut();
                }
            });
            
            $(document).on('click', '.najdenrezultat', function(){
                let product = $(this).text();
                product = product.replace(/\s\s+/g, ' ');
                let product_name = product.split('|||')[0];

                let item = $('#active-item');
                item.val(product_name);

                let addBtn = $('#add-item');
                addBtn.show();

                $('#productList').fadeOut();  
            });
            
            $(document).on('click', '#add-item', function(){
                let new_input = "<br><input type='text' class='product-item form-control custom-search-form' id='active-item'>";
                let current_input = $('#active-item');
                current_input.removeAttr('id');
                current_input.prop("disabled", true);

                let removeBtn = "<i class='fa fa-minus-circle remove-item custom-search-btn' aria-hidden='true'></i>";
                removeBtn = $(removeBtn).insertAfter(current_input);

                $(new_input).insertAfter(removeBtn);
                $('#add-item').hide();
            });

            $(document).on('click', '.remove-item', function(){
                let input = this.previousSibling;
                let line_break = this.nextSibling;
                input.parentElement.removeChild(input);
                this.parentElement.removeChild(this);
                line_break.parentElement.removeChild(line_break);
            });

            $('#submitBtn').click(function(){
                $("#recommended_items").val('[' + getIds().toString() + ']');
                $("#data-form").submit();
            });
        });
    </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sport11rez/public_html/resources/views/product/add.blade.php ENDPATH**/ ?>