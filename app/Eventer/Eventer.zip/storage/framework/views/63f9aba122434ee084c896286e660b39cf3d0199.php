<!DOCTYPE html>
    <html><head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

        <title>Lexagent pogodba št.</title>
    </head>
    <body>
        
    <?php
        echo $company_name;
    ?>
    </body>
</html>
<?php /**PATH /home/sport11rez/public_html/resources/views/contract/pdf-contract.blade.php ENDPATH**/ ?>