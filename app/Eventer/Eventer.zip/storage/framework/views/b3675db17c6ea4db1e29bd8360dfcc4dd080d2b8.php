
<?php /**PATH /home/izposoja1111/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/subcopy.blade.php ENDPATH**/ ?>