<img src="https://izposoja.11-11.si/company_images/logo.png" width="150" height="58" alt="">
<br><br>

<h3>Obvestilo</h3>
<div>Oseba <?php echo e($customer->name . ' ' . $customer->surname); ?>, je danes <?php echo e(date('d.m.Y')); ?> potrdila rezervacijo
od <?php echo e(date('d.m.Y', strtotime($rent->rental_from))); ?> do <?php echo e(date('d.m.Y', strtotime($rent->rental_to))); ?>

za naslednjo opremo:
<ul>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>Artikel: <?php echo e($product->name); ?>, šifra: <?php echo e($product->product_id); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
Rezervacija je bila potrjena s plačilo 20€, skupna cena izposoje: <?php echo e($rent->total_price); ?> EUR.</div>
<br><br>
<i>To je sistemsko generirano sporočilo, zato nanj ne odgovarjajte.</i>
<?php /**PATH /home/sport11rez/public_html/resources/views/mail/info.blade.php ENDPATH**/ ?>
