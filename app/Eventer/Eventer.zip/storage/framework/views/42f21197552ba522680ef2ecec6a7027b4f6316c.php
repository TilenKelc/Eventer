<?php $__env->startComponent('mail::layout'); ?>

    
    <?php echo e($slot); ?>




<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/rezervacijademo/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/message.blade.php ENDPATH**/ ?>