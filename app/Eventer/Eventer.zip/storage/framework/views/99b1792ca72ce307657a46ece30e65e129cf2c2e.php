<?php $__env->startSection('content'); ?>
<div class="container home">
    <div class="row justify-content-center">
      <div class="banner_img">
        <img src="<?php echo e(URL::asset('/image/izposoja-koles-banner-novo-2.jpg')); ?>" alt="Izposoja kolesa"/>
      </div>

      <p>Bi želeli pred nakupom kolo testirati ali pa si le želite na kolo vendar se vam nakup ne zdi smiseln, ker to potrebujete samo nekajkrat na leto? V Šport 11 smo za vas pripravili idealno rešitev: Rent a bike. Vsa kolesa so redno vzdrževana in pripravljena na nove aktivnosti. V naši rent floti lahko poiščete kolesa znamk Focus in Giant.</p>

      <h2 class="subtitle">Poiščite kolo za vas</h2>
      <div class="kartice_odlocitev">
        <a href="javascript:void(0)" id="dateSearchBtn" class="kartica">
          <img src="<?php echo e(URL::asset('/image/Glede na datum.jpg')); ?>" alt="Tip kolesa"/>
          <div class="text">
            <h3>Glede na datum razpoložljivosti</h3>
            <span class="btn custom-submit-btn">Poiščite</span>
          </div>
        </a>
        <a href="/category/index" class="kartica">
          <img src="<?php echo e(URL::asset('/image/Glede na tip kolesa.jpg')); ?>" alt="Tip kolesa"/>
          <div class="text">
            <h3>Glede na tip kolesa</h3>
            <span class="btn custom-submit-btn">Poiščite</span>
          </div>
        </a>
      </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izposoja1111/public_html/resources/views/home-bikes.blade.php ENDPATH**/ ?>