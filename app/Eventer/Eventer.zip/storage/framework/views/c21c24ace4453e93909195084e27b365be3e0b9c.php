<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/izposoja1111/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>