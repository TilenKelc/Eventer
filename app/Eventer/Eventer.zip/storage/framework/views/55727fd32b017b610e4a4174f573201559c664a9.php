<img src="https://izposoja.11-11.si/company_images/logo.png" width="150" height="58" alt="">
<br><br>

<h3>Pozdravljeni <?php echo e($customer->name . ' ' . $customer->surname); ?>,</h3>
<div>obveščamo vas, da se je plačilo rezervacije opreme izvedlo uspešno,
za izposojo od <?php echo e(date('d.m.Y', strtotime($rent->rental_from))); ?> do <?php echo e(date('d.m.Y', strtotime($rent->rental_to))); ?>

za naslednjo opremo:
<ul>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>Artikel: <?php echo e($product->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
Vrednost že plačane akontacije: 40 EUR.
Skupni znesek izposoje izbrane opreme plačate ob prevzemu in znaša <?php echo e($rent->total_price); ?> EUR.</div>
<br>
Lep pozdrav,
ekipa Sport11
<br><br>
<i>To je sistemsko generirano sporočilo, zato nanj ne odgovarjajte.</i>
<?php /**PATH /home/izposoja1111/public_html/resources/views/mail/order.blade.php ENDPATH**/ ?>