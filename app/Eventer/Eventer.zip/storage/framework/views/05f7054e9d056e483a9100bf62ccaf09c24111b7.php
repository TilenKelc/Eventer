
 
<?php $__env->startSection('content'); ?>
 
    <div class="container size_add">
        <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php if($size == null): ?>
            <div class="header">
                <div class="content">Dodajanje novih velikosti</div>
            </div>
            <form action="<?php echo e(url('size/save')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Velikost:</label>
                    <input type="text" class="form-control" name="size">
                </div>

                <div class="form-group submit-btn">
                    <button type="submit" class="btn">Dodaj</button>
                </div>
            </form>            
        <?php else: ?>
            <div class="header">
                <div class="content">Urejanje velikosti</div>
            </div>
            <form action='<?php echo e(url("size/save/$size->id")); ?>' method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group col-md-4">
                    <label class="col-form-label text-md">Velikost:</label>
                    <input type="text" class="form-control" name="size" value="<?php echo e($size->size); ?>">
                </div>

                <div class="form-group submit-btn">
                    <button type="submit" class="btn">Posodobi</button>
                </div>
            </form>
            <form action='<?php echo e(url("size/delete/$size->id")); ?>' method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group submit-btn">
                    <button type="submit" class="btn">Izbriši</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sport11rez/public_html/resources/views/size/add.blade.php ENDPATH**/ ?>